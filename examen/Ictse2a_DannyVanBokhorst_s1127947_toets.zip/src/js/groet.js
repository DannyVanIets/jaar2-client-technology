const gegroet = function(){
    console.log('Gegroet!')
}
